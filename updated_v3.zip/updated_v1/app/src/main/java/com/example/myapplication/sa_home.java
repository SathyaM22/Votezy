package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class sa_home extends AppCompatActivity {

    int LABEL_VISIBILITY_LABELED = BottomNavigationView.LABEL_VISIBILITY_LABELED;
    int LABEL_VISIBILITY_UNLABELED = BottomNavigationView.LABEL_VISIBILITY_UNLABELED;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sa_home);
        BottomNavigationView bottomNavigationView=findViewById(R.id.bottomNavigationView);

      


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.item1:


                        return true;
                    case R.id.item2:
//                        Intent i= new Intent(sa_MainActivity2.this,splash_screen.class);
//                        startActivity(i);


                        return true;
                    case R.id.item3:
//                        i= new Intent(sa_MainActivity2.this,sa_MainActivity2.class);
//                        startActivity(i);

                        return true;




                }
                return false;
            }
        });


    }

}