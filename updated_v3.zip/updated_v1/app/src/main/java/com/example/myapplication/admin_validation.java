package com.example.myapplication;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import pl.droidsonroids.gif.GifImageView;

public class admin_validation extends AppCompatActivity {

    TextInputEditText sa_id;
    String id_read;
    boolean playing = false;
    MediaPlayer mp;
    GifImageView done;
    Button vali,nxt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_validation);
        sa_id=findViewById(R.id.uniq_id);
        done=findViewById(R.id.imageView11);
        done.setVisibility(View.INVISIBLE);
        vali=findViewById(R.id.button2);
        nxt=findViewById(R.id.button4);
        mp = MediaPlayer.create(getApplicationContext(),R.raw.success);
        nxt.setVisibility(View.INVISIBLE);
//Listen on play button
//        play.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                if(!playing){
//                    mp.start();
//                    playing=true;
//                }
//            }
//        });

    }

    public void validate(View v){
        id_read=sa_id.getText().toString();

        FirebaseDatabase db= FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/");
        DatabaseReference node=db.getReference("Christ").child("Admin");
        Query check_name=node.orderByChild("Uid").equalTo(id_read);
       // Query check_name=node.orderByChild().equalTo(id_read);
        // Toast.makeText(sa_MainActivity2.this,, Toast.LENGTH_SHORT).show();

        check_name.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){

                    Toast.makeText(getApplicationContext(), "Sucessfull", Toast.LENGTH_SHORT).show();
                    done.setVisibility(View.VISIBLE);
                    vali.setVisibility(View.INVISIBLE);
                    nxt.setVisibility(View.VISIBLE);
                    if(!playing){
                        mp.start();
                        playing=true;
                    }

                }

                else{
                    Toast.makeText(getApplicationContext(), "Invalid unique id", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
//        if(id_read.equalsIgnoreCase("123456")){
//            Toast.makeText(sa_MainActivity5.this, "Successfull", Toast.LENGTH_SHORT).show();
//            done.setVisibility(View.VISIBLE);
//            vali.setVisibility(View.INVISIBLE);
//            nxt.setVisibility(View.VISIBLE);
//            if(!playing){
//                mp.start();
//                playing=true;
//            }
//        }
//        else{
//            Toast.makeText(sa_MainActivity5.this, "Unsuccessfull", Toast.LENGTH_SHORT).show();
//        }
    }

    public void next(View v) {

        Intent i= new Intent(getApplicationContext(), admin_upload_photo.class);
        startActivity(i);
    }
}