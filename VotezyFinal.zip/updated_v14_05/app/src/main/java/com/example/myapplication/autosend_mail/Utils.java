package com.example.myapplication.autosend_mail;

public class Utils {
    //This is your from email
    public static final String EMAIL = "votezy.india@gmail.com";

    //This is your from email password
    public static final String PASSWORD = "votezy@123";

}