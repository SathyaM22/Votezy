package com.example.myapplication.candidates;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.voters.sa_home;
import com.example.myapplication.voters.splash_voteDone;
import com.example.myapplication.voters.voter_face;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class MyAdapter4 extends RecyclerView.Adapter<MyAdapter4.MyViewHolder> {

    Context context;

    ArrayList<Candidate> list;
    String eename= MyAdapter5.data.getEname();
    String keypass,voter_keypass,vote_status_date,uname;
    String encodedUrl;
    String date;
    int vote_count=1;
    String mailid= sa_home.v_name.getVoter_email();


    public MyAdapter4(Context context, ArrayList<Candidate> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_cname,parent,false);
        return  new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        uname=mailid;
        Candidate user = list.get(position);
        holder.firstName.setText(user.getName());
        holder.lastName.setText(user.getPosition());
        elect_date();
        DatabaseReference rootRef = FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
        Query query = rootRef.child("Christ").child("Voters").orderByChild("email").equalTo(uname);

        ValueEventListener valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    String key = ds.getKey();
                    Log.d("", key);
                    voter_keypass=key;
                    DatabaseReference ref = FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
                    DatabaseReference applesQuery = ref.child("Christ").child("Voters").child(voter_keypass);
                    applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if (dataSnapshot.hasChild(vote_status_date)) {
                                //Toast.makeText(getApplicationContext(), s_Email + " Email Already Exists", Toast.LENGTH_LONG).show();
                                Log.d("", "Already Voted");
                                holder.vote.setVisibility(View.GONE);

                            }



                        }
                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            Log.e( "onCancelled", String.valueOf(databaseError.toException()));
                        }
                    });



                    //  Toast.makeText(context, keypass, Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("", databaseError.getMessage());
            }
        };
        query.addListenerForSingleValueEvent(valueEventListener);

        // holder.age.setText(user.getValid_status());

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context.getApplicationContext(), user.getName(), Toast.LENGTH_SHORT).show();

            }
        });
        
        holder.vote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // date=firebaseTimestampObject.toDate()

                //Toast.makeText(context.getApplicationContext(), "asas", Toast.LENGTH_SHORT).show();

                get_elect_pkey(user);
//                Intent i= new Intent(context.getApplicationContext(), voter_face.class);
//                context.startActivity(i);

                //Toast.makeText(context, keypass, Toast.LENGTH_SHORT).show();

            }
        });

        holder.doath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context.getApplicationContext(), "Downloading", Toast.LENGTH_SHORT).show();
                DatabaseReference rootRef = FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
                Query query = rootRef.child("Christ").child("Elections").child(eename).child("candidates").orderByChild("Name").equalTo(user.getName());
                ValueEventListener valueEventListener = new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for(DataSnapshot ds : dataSnapshot.getChildren()) {
                            String key = ds.getKey();
                            Log.d("", key);
                            keypass=key;
                            downloadfile();
                          //  Toast.makeText(context, keypass, Toast.LENGTH_SHORT).show();

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.d("", databaseError.getMessage());
                    }
                };
                query.addListenerForSingleValueEvent(valueEventListener);


            }


        });
       //

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView firstName, lastName, doath;
        CardView cardView;
        Button vote;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            firstName = itemView.findViewById(R.id.tvElectName);
            lastName = itemView.findViewById(R.id.tvlastName);
            //age = itemView.findViewById(R.id.tvage);
            cardView = itemView.findViewById(R.id.cardView);
            vote=itemView.findViewById(R.id.button16);
            doath=itemView.findViewById(R.id.downloadOath);
        }
    }
    public void get_elect_pkey(Candidate user){
        DatabaseReference rootRef = FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
        Query query = rootRef.child("Christ").child("Elections").child(eename).child("candidates").orderByChild("Name").equalTo(user.getName());

        ValueEventListener valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    String key = ds.getKey();
                    Log.d("", key);
                    keypass=key;
                    voteRegister();

                    //  Toast.makeText(context, keypass, Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("", databaseError.getMessage());
            }
        };
        query.addListenerForSingleValueEvent(valueEventListener);
    }
    public void voteRegister(){
      //  String pnode= pkey;
        //vote_count = 0;
        DatabaseReference rootRef = FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
        DatabaseReference vote_ref=rootRef.child("Christ").child("Elections").child(eename).child("candidates").child(keypass).child("Votes");
        vote_ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                vote_count =Integer.parseInt(snapshot.getValue().toString());
                vote_count+=1;
                Log.d("", "Inside Vote "+Integer.toString(vote_count));


                // after getting the value we are setting
                // our value to our text view in below line.
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // calling on cancelled method when we receive
                // any error or we are not able to get the data.
            }
        });
        vote_ref.setValue(vote_count);
        get_voter_pkey();


    }

    public void get_voter_pkey(){
        DatabaseReference rootRef = FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
        Query query = rootRef.child("Christ").child("Voters").orderByChild("email").equalTo(uname);

        ValueEventListener valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    String key = ds.getKey();
                    Log.d("", key);
                    voter_keypass=key;
                    votes_status();



                    //  Toast.makeText(context, keypass, Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("", databaseError.getMessage());
            }
        };
        query.addListenerForSingleValueEvent(valueEventListener);
    }
    public void elect_date(){
        DatabaseReference rootRef = FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
        DatabaseReference vote_date_ref=rootRef.child("Christ").child("Elections").child(eename).child("date");
        vote_date_ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                vote_status_date =snapshot.getValue().toString();

                Log.d("", "Inside Vote "+vote_status_date);


                // after getting the value we are setting
                // our value to our text view in below line.
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // calling on cancelled method when we receive
                // any error or we are not able to get the data.
            }
        });
    }
    public void votes_status(){
        DatabaseReference ref = FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
        DatabaseReference applesQuery = ref.child("Christ").child("Voters").child(voter_keypass).child(vote_status_date);
        applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
           @Override
           public void onDataChange(DataSnapshot dataSnapshot) {
                   if (dataSnapshot.exists()) {
                       //Toast.makeText(getApplicationContext(), s_Email + " Email Already Exists", Toast.LENGTH_LONG).show();


                   } else {
                       Log.d("", vote_status_date);
                       ref.child("Christ").child("Voters").child(voter_keypass).child(vote_status_date).setValue("done");
                   }



           }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e( "onCancelled", String.valueOf(databaseError.toException()));
            }
        });

    }
   /** public String getpkey(Candidate user){


        return keypass;
    }**/
    public void downloadfile() {
        Toast.makeText(context, keypass, Toast.LENGTH_SHORT).show();
//        FirebaseStorage storage = FirebaseStorage.getInstance();
//        StorageReference storageRef = storage.getReferenceFromUrl("https://firebasestorage.googleapis.com/v0/b/votezytesting.appspot.com/o/Christ%2FElections%2FClass%20Rept%2FCandidates%2Fjawa12%2Foath?alt=media&token=40b7d0b0-d18f-44fd-8b68-37920aae2736");

       FirebaseStorage storage = FirebaseStorage.getInstance("gs://votezytesting.appspot.com/");
      StorageReference storageReference = storage.getReference().child("Christ/Elections/"+eename+"/Candidates/"+keypass+"/oath");

        storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                // Got the download URL for 'users/me/profile.png'
                //  Toast.makeText(getApplicationContext(), "success", Toast.LENGTH_SHORT).show();
                Log.e("",uri.toString());
                String word=uri.toString();
                try {
                    URL url = new URL(word);
                    String encodedUrl2= URLEncoder.encode(url.toString(),"UTF-8");
                    encodedUrl=word;
                    Log.e("",String.valueOf(url));
                    Log.e("",encodedUrl);
                    //u1=encodedUrl;
                    //Toast.makeText(getApplicationContext(), , Toast.LENGTH_SHORT).show();
                } catch (MalformedURLException | UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // Handle any errors
            }
        });

        //StorageReference storageRef = storage.g;






        ProgressDialog pd = new ProgressDialog(context);
        pd.setTitle("oath.jpg");
        pd.setMessage("Downloading Please Wait!");
        pd.setIndeterminate(true);
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.show();


        final File rootPath = new File(Environment.getExternalStorageDirectory(), "Download");

        if (!rootPath.exists()) {
            rootPath.mkdirs();
        }


        final File localFile = new File(rootPath, "oath.jpg");

        storageReference.getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                Log.e("firebase ", ";local tem file created  created " + localFile.toString());

//                if (!peekWallpaper().isVisible()){
//                    return;
//                }

                if (localFile.canRead()){

                    pd.dismiss();
                }

                Toast.makeText(context, "Download Completed", Toast.LENGTH_SHORT).show();
                //  Toast.makeText(samp_MainActivity2.this, "Internal storage/MADBO/Nature.jpg", Toast.LENGTH_LONG).show();

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Log.e("firebase ", ";local tem file not created  created " + exception.toString());
                Toast.makeText(context, "Download Incompleted", Toast.LENGTH_LONG).show();
            }
        });
    }

}
