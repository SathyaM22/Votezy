package com.example.myapplication;

public class Candidate {

    String Name,Position,Ename;

    public String getName() {
        return Name;
    }

    public String getPosition() {
        return Position;
    }

    //     System.out.p
//        System.out.println(holder.lastName);
//        System.out.println(holder.age);


    public String getEname() {
        return Ename;
    }
}

    /*public String getName() {
        return Name;
    }

    public String getVotes() {
        return Votes;
    }

    public String getPosition() {
        return Position;
    }

//    public String getLocation() {
//        return Location;
//    }
}*/
