package com.example.myapplication;

public class admin_add_details {
    private String eMail,Uid;
    private int valid_status;
    public admin_add_details(String eMail,String Uid,int valid_status){
        this.eMail=eMail;
        this.Uid=Uid;
        this.valid_status=valid_status;
    }
    public String geteMail() {
        return eMail;
    }

    public String getUid() {
        return Uid;
    }

    public void setUid(String uid) {
        Uid = uid;
    }

    public int getValid_status() {
        return valid_status;
    }

    public void setValid_status(int valid_status) {
        this.valid_status = valid_status;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }
}

