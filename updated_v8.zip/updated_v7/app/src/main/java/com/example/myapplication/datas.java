package com.example.myapplication;

public class datas {
    String ename;



    public void setEname(String ename) {
        this.ename = ename;
    }

    public datas(String ename) {
        this.ename = ename;
    }

    public String getEname() {
        return ename;
    }
}
