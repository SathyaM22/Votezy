package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.core.Tag;

import java.util.HashMap;
import java.util.Map;
import java.util.Queue;

public class sa_MainActivity2 extends AppCompatActivity {
    TextInputEditText sa_t1,sa_t2, sa_t3;
    Button sa_b1;
    String sa_votid,sa_pass, sa_cc;
    private DatabaseReference df;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sa_main2);
        sa_b1=findViewById(R.id.sb_button_login);
        sa_t1=findViewById(R.id.uniq_id);
        sa_t2=findViewById(R.id.sb_in_password);

//        sa_b1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//
////                FirebaseDatabase database = FirebaseDatabase.getInstance();
////                DatabaseReference myRef = database.getReference();
////
////                Map<String, String> user = new HashMap<>();
////                user.put("Full Name:", " Satya");
////
////                myRef.setValue(user);
////                Toast.makeText(sa_MainActivity2.this, "Successfull", Toast.LENGTH_SHORT).show();
//            }
//        });

    }

    public void loginUser(View v){

        sa_votid=sa_t1.getText().toString();
        sa_pass=sa_t2.getText().toString();
        FirebaseDatabase db= FirebaseDatabase.getInstance("https://sample-cb944-default-rtdb.asia-southeast1.firebasedatabase.app/");
        DatabaseReference node=db.getReference("students");
        Query check_name=node.orderByChild("uid").equalTo(sa_votid);
       // Toast.makeText(sa_MainActivity2.this,, Toast.LENGTH_SHORT).show();

        check_name.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    String check_pass=snapshot.child(sa_votid).child("password").getValue(String.class);
                    if(check_pass.equals(sa_pass)){
                        Toast.makeText(sa_MainActivity2.this, "Sucessfull", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(getApplicationContext(),sa_MainActivity8.class);
                        startActivity(i);
                    }
                    else{
                        Toast.makeText(sa_MainActivity2.this, "Invalid password", Toast.LENGTH_SHORT).show();
                    }
                }

                else{
                    Toast.makeText(sa_MainActivity2.this, "Invalid username", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




//        if(sa_votid.isEmpty() || sa_pass.isEmpty()){
//            Toast.makeText(sa_MainActivity2.this, "Both the fields are required!!", Toast.LENGTH_SHORT).show();
//        }
//        else{
//
//
//            Toast.makeText(sa_MainActivity2.this, "Successfull", Toast.LENGTH_SHORT).show();
//        }


    }

    public void register_screen(View v){
        Intent i= new Intent(sa_MainActivity2.this,sa_MainActivity5.class);
        startActivity(i);
    }
}

