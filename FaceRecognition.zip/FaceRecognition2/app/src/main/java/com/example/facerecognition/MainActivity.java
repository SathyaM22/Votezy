package com.example.facerecognition;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    TextView t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1=findViewById(R.id.textView);
        // compareTwoFaces();
        //  apii();
    }
    public void apii(View v)  {
        OkHttpClient client = new OkHttpClient();
        String source="https%3A%2F%2Ffirebasestorage.googleapis.com%2Fv0%2Fb%2Fvotezytesting.appspot.com%2Fo%2FVoters%252F123455%252FId-card%3Falt%3Dmedia%26token%3Dfb73403e-f09f-421d-89eb-01b731a92fe7";
        String target="https%3A%2F%2Ffirebasestorage.googleapis.com%2Fv0%2Fb%2Fvotezytesting.appspot.com%2Fo%2FVoters%252F123455%252FId-card%3Falt%3Dmedia%26token%3Dfb73403e-f09f-421d-89eb-01b731a92fe7";
        //String source="https://images.unsplash.com/photo-1517487313006-d80558d7a5cb?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80";
        //String target="https://images.unsplash.com/photo-1517487313006-d80558d7a5cb?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80";

        Toast.makeText(getApplicationContext(), "called", Toast.LENGTH_SHORT).show();
        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "source_url="+source+"&target_url="+target);
        Request request = new Request.Builder()
                .url("https://webit-face.p.rapidapi.com/similarity")
                .post(body)
                .addHeader("content-type", "application/x-www-form-urlencoded")
                .addHeader("x-rapidapi-host", "webit-face.p.rapidapi.com")
                .addHeader("x-rapidapi-key", "0b452a8f4cmshc7b8c7efcaa7883p1dd51bjsn613f3db4966e")
                .build();
//        OkHttpClient client = new OkHttpClient();
//
//        Request request = new Request.Builder()
//                .url("https://love-calculator.p.rapidapi.com/getPercentage?sname=Alice&fname=John")
//                .get()
//                .addHeader("x-rapidapi-host", "love-calculator.p.rapidapi.com")
//                .addHeader("x-rapidapi-key", "0b452a8f4cmshc7b8c7efcaa7883p1dd51bjsn613f3db4966e")
//                .build();


        //  Response response = client.newCall(request).execute();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.e("","not done");
                // Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if(response.isSuccessful()){
                    Log.e("","done");
                    String resp= response.body().string();
                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                JSONObject jsonObject= new JSONObject(resp);
                             //   JSONObject data = (JSONObject) jsonObject.get("data");
                            //    System.out.println("\tmatches: " + data);

 //                               JSONArray matches = (JSONArray) data.get("matches");
   //                             System.out.println("\tmatches: " + matches);
//                               // Iterator itr = matches.it();
//
//                               // while (itr.hasNext()) {
//
////                                    Object slide = itr.next();
                                //   JSONObject jsonObject2 = (JSONObject) slide;
//                                JSONObject info = (JSONObject) jsonObject.get("0");
//
//                                String similarity = (String) info.get("similarity");
//                                //  String name_id = (String) info.get("name_id");
//
//                                System.out.println("\t\tsimilarity: " + similarity);
//                                    //System.out.println("\t\tName Id: " + name_id);
//                              //  }

                                 String val1=jsonObject.getString("status");
                                //String val2=jsonObject.getString("result");
                                t1.setText(val1);
                                Log.e("","done");
                            }
                            catch (JSONException e){
                                e.printStackTrace();
                            }
                        }
                    });
                }
            }
        });

        // Responss response = client.newCall(request).execute();
    }
}