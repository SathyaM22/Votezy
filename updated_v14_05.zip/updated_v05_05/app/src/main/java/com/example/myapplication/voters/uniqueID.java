package com.example.myapplication.voters;

public class uniqueID {
    String UID;
    public uniqueID(String UID) {
        this.UID = UID;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }



}
