package com.example.myapplication.voters;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.myapplication.R;

public class splash_voteDone extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_vote_done);
    }
    public void back(View v){
        Intent i= new Intent(getApplicationContext(),sa_home.class);
        startActivity(i);
    }
}