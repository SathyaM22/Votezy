package com.example.myapplication.candidates;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.samp_MainActivity2;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MyAdapter4 extends RecyclerView.Adapter<MyAdapter4.MyViewHolder> {

    Context context;

    ArrayList<Candidate> list;
    String eename= MyAdapter5.data.getEname();
    String keypass;
    String encodedUrl;


    public MyAdapter4(Context context, ArrayList<Candidate> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_cname,parent,false);
        return  new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Candidate user = list.get(position);
        holder.firstName.setText(user.getName());
        holder.lastName.setText(user.getPosition());
        // holder.age.setText(user.getValid_status());

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context.getApplicationContext(), user.getName(), Toast.LENGTH_SHORT).show();

            }
        });
        
        holder.vote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context.getApplicationContext(), "Vote!!", Toast.LENGTH_SHORT).show();
            }
        });

        holder.doath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context.getApplicationContext(), "Downloading", Toast.LENGTH_SHORT).show();
                DatabaseReference rootRef = FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
                Query query = rootRef.child("Christ").child("Elections").child(eename).child("candidates").orderByChild("Name").equalTo(user.getName());
                ValueEventListener valueEventListener = new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for(DataSnapshot ds : dataSnapshot.getChildren()) {
                            String key = ds.getKey();
                            Log.d("", key);
                            keypass=key;
                            downloadfile();
                          //  Toast.makeText(context, keypass, Toast.LENGTH_SHORT).show();

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.d("", databaseError.getMessage());
                    }
                };
                query.addListenerForSingleValueEvent(valueEventListener);


            }


        });
       //

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView firstName, lastName, doath;
        CardView cardView;
        Button vote; 
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            firstName = itemView.findViewById(R.id.tvElectName);
            lastName = itemView.findViewById(R.id.tvlastName);
            //age = itemView.findViewById(R.id.tvage);
            cardView = itemView.findViewById(R.id.cardView);
            vote=itemView.findViewById(R.id.button16);
            doath=itemView.findViewById(R.id.downloadOath);
        }
    }
    public void downloadfile() {
        Toast.makeText(context, keypass, Toast.LENGTH_SHORT).show();
//        FirebaseStorage storage = FirebaseStorage.getInstance();
//        StorageReference storageRef = storage.getReferenceFromUrl("https://firebasestorage.googleapis.com/v0/b/votezytesting.appspot.com/o/Christ%2FElections%2FClass%20Rept%2FCandidates%2Fjawa12%2Foath?alt=media&token=40b7d0b0-d18f-44fd-8b68-37920aae2736");

       FirebaseStorage storage = FirebaseStorage.getInstance("gs://votezytesting.appspot.com/");
      StorageReference storageReference = storage.getReference().child("Christ/Elections/"+eename+"/Candidates/"+keypass+"/oath");

        storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                // Got the download URL for 'users/me/profile.png'
                //  Toast.makeText(getApplicationContext(), "success", Toast.LENGTH_SHORT).show();
                Log.e("",uri.toString());
                String word=uri.toString();
                try {
                    URL url = new URL(word);
                    String encodedUrl2= URLEncoder.encode(url.toString(),"UTF-8");
                    encodedUrl=word;
                    Log.e("",String.valueOf(url));
                    Log.e("",encodedUrl);
                    //u1=encodedUrl;
                    //Toast.makeText(getApplicationContext(), , Toast.LENGTH_SHORT).show();
                } catch (MalformedURLException | UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // Handle any errors
            }
        });

        //StorageReference storageRef = storage.g;






        ProgressDialog pd = new ProgressDialog(context);
        pd.setTitle("oath.jpg");
        pd.setMessage("Downloading Please Wait!");
        pd.setIndeterminate(true);
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.show();


        final File rootPath = new File(Environment.getExternalStorageDirectory(), "Download");

        if (!rootPath.exists()) {
            rootPath.mkdirs();
        }


        final File localFile = new File(rootPath, "oath.jpg");

        storageReference.getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                Log.e("firebase ", ";local tem file created  created " + localFile.toString());

//                if (!peekWallpaper().isVisible()){
//                    return;
//                }

                if (localFile.canRead()){

                    pd.dismiss();
                }

                Toast.makeText(context, "Download Completed", Toast.LENGTH_SHORT).show();
                //  Toast.makeText(samp_MainActivity2.this, "Internal storage/MADBO/Nature.jpg", Toast.LENGTH_LONG).show();

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Log.e("firebase ", ";local tem file not created  created " + exception.toString());
                Toast.makeText(context, "Download Incompleted", Toast.LENGTH_LONG).show();
            }
        });
    }

}
