package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class admin_login extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rj_activity_admin_login);
    }
    public void admin_validate(View view){
        Intent intent = new Intent(getApplicationContext(),admin_validation.class);
        startActivity(intent);
    }
    public void admin_login(View view){

        // Write a message to the database
        Intent intent = new Intent(getApplicationContext(),admin_add_users.class);
        startActivity(intent);
    }


}
/*

 */