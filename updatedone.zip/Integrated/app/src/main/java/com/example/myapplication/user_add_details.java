package com.example.myapplication;

public class user_add_details {
    public user_add_details(String eMail, String uid) {
        this.eMail = eMail;
        this.uid = uid;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    private String eMail,uid;
//    public user_add_details(String eMail){
//        this.eMail=eMail;
//    }
//    public String geteMail() {
//        return eMail;
//    }
//
//    public void seteMail(String eMail) {
//        this.eMail = eMail;
//    }




}