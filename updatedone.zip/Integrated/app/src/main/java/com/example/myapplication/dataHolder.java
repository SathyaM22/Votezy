package com.example.myapplication;

public class dataHolder {
    String name,organization,password,email,uniq;

    public String getUniq() {
        return uniq;
    }

    public void setUniq(String uniq) {
        this.uniq = uniq;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String uid) {
        this.email = email;
    }

    public dataHolder(String name, String organization, String password, String email, String uniq) {
        this.name = name;
        this.organization = organization;
        this.password = password;
        this.email=email;
        this.uniq=uniq;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
