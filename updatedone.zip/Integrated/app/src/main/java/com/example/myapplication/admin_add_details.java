package com.example.myapplication;

public class admin_add_details {
    private String eMail;
    public admin_add_details(String eMail){
        this.eMail=eMail;
    }
    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }
}
