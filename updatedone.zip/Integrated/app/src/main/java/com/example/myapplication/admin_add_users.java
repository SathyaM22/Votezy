package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.UUID;

public class admin_add_users extends AppCompatActivity {
    Button add,delete;
    FirebaseDatabase rootNode;
    DatabaseReference reference_root,reference_uid;
    EditText etEmail;
    String mailID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add_users);
        etEmail=findViewById(R.id.email);
        add=findViewById(R.id.add_user);
        delete=findViewById(R.id.delete_user);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rootNode=FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/");
                reference_root=rootNode.getReference().child("Users");
                mailID=etEmail.getText().toString();
                String mailS []=mailID.split(",");


                Toast.makeText(getApplicationContext(),reference_root.toString(),Toast.LENGTH_LONG).show();
                for(String  single_Email: mailS){
                    String uniqueID = UUID.randomUUID().toString().substring(0,18);
                    reference_root=reference_root.getDatabase().getReference("Users").child(uniqueID);
                    user_add_details edetail= new user_add_details(single_Email,uniqueID);
                    reference_uid=reference_root;
                    reference_uid.setValue(edetail);


                }

            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mailID=etEmail.getText().toString();
                String mailS []=mailID.split(",");
                for(String  single_Email: mailS){
                    delete_user(single_Email);
                }

            }
        });
    }
private void delete_user(String s_Email){
    DatabaseReference ref = FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
    Query applesQuery = ref.child("Users").orderByChild("eMail").equalTo(s_Email);

    applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot dataSnapshot) {
            for (DataSnapshot appleSnapshot: dataSnapshot.getChildren()) {
                if (appleSnapshot.exists()) {
                    appleSnapshot.getRef().removeValue();
                }
                else {
                    Toast.makeText(getApplicationContext(),s_Email + " Email Does Not Exist",Toast.LENGTH_LONG).show();
                }

            }
        }

        @Override
        public void onCancelled(DatabaseError databaseError) {
            // Log.e(TAG, "onCancelled", databaseError.toException());
        }
    });
}
}
