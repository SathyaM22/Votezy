package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class admin_registeration extends AppCompatActivity {

    ImageView sa_iv1;
    TextInputEditText nm,cs,du,ro;
    Button btn;

    private static final int pic_id = 123;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_registeration);
        nm=findViewById(R.id.inp1);
        cs=findViewById(R.id.inp2);
        du=findViewById(R.id.inp3);
        ro=findViewById(R.id.inp4);
        btn=findViewById(R.id.button6);
    }


    public void connect(View v){


        String uid=ro.getText().toString().trim();
        String name=nm.getText().toString().trim();
        String organization=cs.getText().toString().trim();
        String password=du.getText().toString().trim();

        admin_details obj=new admin_details(name,organization,password,uid);

        FirebaseDatabase db= FirebaseDatabase.getInstance("https://fir-1-4c1db-default-rtdb.asia-southeast1.firebasedatabase.app/");
        DatabaseReference node= db.getReference("students");

        if(!uid.isEmpty()||!name.isEmpty()||!organization.isEmpty()||!password.isEmpty()){
            node.child(uid).setValue(obj);
            Toast.makeText(getApplicationContext(), "Registeration successfull", Toast.LENGTH_SHORT).show();
            ro.setText("");
            nm.setText("");
            cs.setText("");
            du.setText("");
           // Intent i =new Intent(getApplicationContext(), sa_login.class);
           // startActivity(i);

        }
        else{
            Toast.makeText(getApplicationContext(), "All the fields are required", Toast.LENGTH_SHORT).show();

        }


//        FirebaseDatabase database = FirebaseDatabase.getInstance();
//        DatabaseReference myRef = database.getReference("user");
//
//        myRef.setValue("Hello");
    }


}