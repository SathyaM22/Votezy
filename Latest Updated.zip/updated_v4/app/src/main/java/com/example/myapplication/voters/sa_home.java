package com.example.myapplication.voters;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.myapplication.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class sa_home extends AppCompatActivity {

    int LABEL_VISIBILITY_LABELED = BottomNavigationView.LABEL_VISIBILITY_LABELED;
    int LABEL_VISIBILITY_UNLABELED = BottomNavigationView.LABEL_VISIBILITY_UNLABELED;

    public static final String SHARED_PREFS = "shared_prefs";

    // key for storing email.
    public static final String EMAIL_KEY = "email_key";

    // key for storing password.
    public static final String PASSWORD_KEY = "password_key";
    String email;
    TextView namee,orgname;
    // variable for shared preferences.
    SharedPreferences sharedpreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sa_home);
        BottomNavigationView bottomNavigationView=findViewById(R.id.bottomNavigationView);
        namee=findViewById(R.id.textView7);
        orgname=findViewById(R.id.textView21);
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);

        // getting data from shared prefs and
        // storing it in our string variable.
        email = sharedpreferences.getString(EMAIL_KEY, null);


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.item1:


                        return true;
                    case R.id.item2:
//                        Intent i= new Intent(sa_MainActivity2.this,splash_screen.class);
//                        startActivity(i);


                        return true;
                    case R.id.item3:
                       Intent i= new Intent(sa_home.this,sa_profile.class);
                        startActivity(i);

                        return true;




                }
                return false;
            }
        });
        DatabaseReference db = FirebaseDatabase.getInstance("https://votezytesting-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("Christ").child("Voters");
        Query query = db.orderByChild("email").equalTo(email);//.orderByValue().equalTo("Salary");


        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot userSnapshot: dataSnapshot.getChildren()) {
                    String eType = userSnapshot.child("name").getValue(String.class);
                    String eType2 = userSnapshot.child("organization").getValue(String.class);
                    namee.setText(eType.toUpperCase());
                    orgname.setText(eType2.toUpperCase());
                    //Log.d("",eType);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                throw databaseError.toException();
            }
        });


    }
    public void logout(View v) {

        // calling method to edit values in shared prefs.
        SharedPreferences.Editor editor = sharedpreferences.edit();

        // below line will clear
        // the data in shared prefs.
        editor.clear();

        // below line will apply empty
        // data to shared prefs.
        editor.apply();

        // starting mainactivity after
        // clearing values in shared preferences.
        Intent i = new Intent(sa_home.this,sa_login.class);
        startActivity(i);
        finish();
    }

}